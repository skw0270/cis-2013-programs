<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 
class Main extends CI_Controller {
 
    function __construct()
    {
        parent::__construct();
 
        /* Standard Libraries of codeigniter are required */
        $this->load->database();
        $this->load->helper('url');
        /* ------------------ */ 
 
        $this->load->library('grocery_CRUD');
 
    }
	
 
    public function index()
    {
        echo "<h1>Welcome to the world of Codeigniter</h1>";//Just an example to ensure that we get into the function
                die();
    }
	

 
    public function employees()
    {
        $crud = new grocery_CRUD();
        $crud->set_table('employees');
		$crud->set_subject('Employee');
		$crud->display_as('officeCode', 'Office Code');
		$crud->display_as('jobTitle', 'Job Title');
		$crud->required_fields('officeCode');
		$crud->field_type('officeCode', 'dropdown', array('1' => '1234', '2' => '2222'));
		$crud->where('jobTitle', 'President1');
		$crud->set_rules('lastName','Last Name','htmlspecialchars|required|min_length[2]|max_length[30]');
		$crud->set_rules('firstNameName','First Name','htmlspecialchars|required|min_length[2]|max_length[30]');

        $output = $crud->render();
		$output->title="Employees";
        $this->_example_output($output);        
    }
	
	public function customers()
	{
		$crud = new grocery_CRUD();
		$crud->set_table('customers_main');
		$crud->set_subject('Customer');
		$crud->columns('email','first_name','state','zip', 'phone', 'membership_type', 'password');  //display columns
		$crud->fields('email','first_name','state','zip','phone', 'membership_type', 'password'); //form fields
		$crud->display_as('phone', 'Phone Number');
		$crud->field_type('password', 'password');
		$crud->callback_before_insert(array($this,'encrypt_pw'));
		$output = $crud->render();
		$output->title="Customers";
		$this->_example_output($output);
		
	
	}
 
    function _example_output($output = null)
 
    {
        $this->load->view('our_template.php',$output);    
    }


function encrypt_pw($post_array) {
			    if(!empty($post_array['password'])) {
					$post_array['password'] = SHA1($_POST['password']);
			    }//if
			    return $post_array;
	    }//function
}
/* End of file Main.php */
/* Location: ./application/controllers/Main.php */